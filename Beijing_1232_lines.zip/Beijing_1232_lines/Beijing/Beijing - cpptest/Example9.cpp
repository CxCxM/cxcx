typedef char gchar;

void func()
{
  gchar buf[10];
}
