//Reading unbounded stream from standard input

#include <iostream>
int main(void) {
 char Password[80];
 puts("Enter 8 character password:");
gets(Password);

}

