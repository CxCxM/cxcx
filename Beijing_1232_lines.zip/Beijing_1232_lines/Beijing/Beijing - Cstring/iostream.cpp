#include   <iostream> 
//#include   <vector> 
//#include   <string> 
//#include <iostream>
using namespace std;
//#include <fstream>

  int main(void) {
  char buf[12];
  cin >> buf;
  cout << "echo: " << buf << endl;

 }