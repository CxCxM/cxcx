//Unbounded string strcpy and concatenation,Cxdeveloper can not find
#include   <iostream> 
int  main(int argc, char* argv[])
{
 
 char a[30];
 char b[20];
 strcpy(a,argv[1]);
 // memcpy(a,argv[1],strlen(argv[1]));
 strcpy(b,argv[1]);

 }